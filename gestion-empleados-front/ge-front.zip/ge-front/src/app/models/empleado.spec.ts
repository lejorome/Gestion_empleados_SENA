import { Empleado } from './empleado';

describe('Empleado', () => {
  it('should create an instance', () => {
    expect(new Empleado()).toBeTruthy();
  });
});
